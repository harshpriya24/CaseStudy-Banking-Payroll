package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.execptions.AccountBlockedException;
import com.cg.banking.execptions.AccountNotFoundException;
import com.cg.banking.execptions.BankingServicesDownException;
import com.cg.banking.execptions.InsufficientAmountException;
import com.cg.banking.execptions.InvalidAccountException;
import com.cg.banking.execptions.InvalidAmountException;
import com.cg.banking.execptions.InvalidPinNumberException;

public class BankingServicesImpl implements BankingServices {

	AccountDAO accountdao=new AccountDAOImpl();
	Account account=new Account();
	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountException, BankingServicesDownException {
		
			return accountdao.save(new Account(accountType, initBalance));
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
	     Account account=  getAccountDetails(accountNo);
	     return account.getAccountBalance()+amount; 
	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws AccountNotFoundException, InvalidPinNumberException, InsufficientAmountException, AccountBlockedException ,BankingServicesDownException{
	Account account=getAccountDetails(accountNo);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked"))
			try{
				throw new AccountBlockedException();
			}
	catch(AccountBlockedException e) {
	  e.printStackTrace();}
	else if(account.getPinNumber()!=pinNumber)throw new InvalidPinNumberException();
		else if(account.getAccountBalance()-amount<1000)throw new InsufficientAmountException();
		else
			account.setAccountBalance(account.getAccountBalance()-amount);
	return account.getAccountBalance();
	}

	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
		BankingServicesDownException, AccountBlockedException {
		Account customerNoTo=getAccountDetails(accountNoTo);
		Account customerNoFrom=getAccountDetails(accountNoFrom);
		if((customerNoTo.getAccountStatus().equalsIgnoreCase("Blocked")||customerNoFrom.getAccountStatus().equalsIgnoreCase("Blocked")))throw  new AccountBlockedException();
		else if(customerNoFrom.getPinNumber()!=pinNumber)throw new InvalidPinNumberException();
		else if (customerNoFrom.getAccountBalance()-transferAmount<1000)throw new InsufficientAmountException();
		else {
			customerNoTo.setAccountBalance(customerNoTo.getAccountBalance()+transferAmount);
			customerNoFrom.setAccountBalance(customerNoFrom.getAccountBalance()-transferAmount);
		}
				
				return true;
	}

	@Override
	public Account getAccountDetails(long accountNo) throws BankingServicesDownException, AccountNotFoundException {
	
		Account account=accountdao.findOne(accountNo);
		if(account==null) throw new AccountNotFoundException();
		return account;
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		
		return null;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) throws BankingServicesDownException {
		
		return null;
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
 Account account=getAccountDetails(accountNo);
 if(account.getAccountStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException();
 else
		return "active";
	}

}
