package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.BankingDBUtil.BankingDBUtil;
import com.cg.banking.beans.Transaction;

public class TransanctionDAOServices implements TransactionDAO{

	@Override
	public Transaction save(Long accountNo,Transaction transaction) {
		transaction.setTransactionId(BankingDBUtil.getTRANSANCTION_NUMBER());
		BankingDBUtil.accounts.get(accountNo).getTransactions().put((long)transaction.getTransactionId(),transaction);
		return transaction;
	}

	

	@Override
	public Transaction findOne(Long accountNo,int traansactionid) {
	
		 	return BankingDBUtil.accounts.get(accountNo).getTransactions().get(traansactionid);
	}

	@Override
	public List<Transaction> findAll(int accNo) {
		
	
		return new ArrayList<Transaction>(BankingDBUtil.accounts.get(accNo).getTransactions().values());
	}

}
