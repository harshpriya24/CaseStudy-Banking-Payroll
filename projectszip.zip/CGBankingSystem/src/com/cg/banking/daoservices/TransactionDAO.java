package com.cg.banking.daoservices;

import java.util.List;

import com.cg.banking.beans.Transaction;

public interface TransactionDAO {
 Transaction save(Long accountNo,Transaction transaction);
 Transaction findOne(Long accountNo,int traansactionid);
 List<Transaction> findAll(int accNo);
}
