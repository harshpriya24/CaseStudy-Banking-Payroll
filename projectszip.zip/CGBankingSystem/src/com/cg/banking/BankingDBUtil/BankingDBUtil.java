package com.cg.banking.BankingDBUtil;

import java.util.HashMap;

import com.cg.banking.beans.Account;

public class BankingDBUtil {
public static HashMap<Long,Account> accounts=new HashMap<>();
private static long ACCOUNT_NUMBER_COUNTER=100;
public static long  getACCOUNT_NUMBER_COUNTER() {
	  return ++ACCOUNT_NUMBER_COUNTER;
}
 ;
 public static int  getPIN_NUMBER_COUNTER() {
	  return  (int)(Math.random()*1000);
}
 private static int TRANSANCTION_NUMBER_COUNTER=100;
 public static int  getTRANSANCTION_NUMBER() {
	  return ++TRANSANCTION_NUMBER_COUNTER;
}
}
