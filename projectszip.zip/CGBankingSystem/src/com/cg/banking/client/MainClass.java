package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.execptions.AccountBlockedException;
import com.cg.banking.execptions.AccountNotFoundException;
import com.cg.banking.execptions.BankingServicesDownException;
import com.cg.banking.execptions.InsufficientAmountException;
import com.cg.banking.execptions.InvalidAccountException;
import com.cg.banking.execptions.InvalidAmountException;
import com.cg.banking.execptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {

	public static void main(String[] args) throws InvalidAmountException, InvalidAccountException, BankingServicesDownException, AccountNotFoundException, InvalidPinNumberException, InsufficientAmountException, AccountBlockedException {
		
	 int accNo,pinNo,accNoFrom,accNoTo;
	 float amount;
	 BankingServices services=new BankingServicesImpl();
	 Account c1=null;
	 Account c2=null;
	 c1=services.openAccount("Savings",2000);
	 c1.setAccountStatus("Active");
	 c2=services.openAccount("Savings", 9000);
	 c2.setAccountStatus("Active");
	 
	 System.out.println("Account details\n"+c1);
	 System.out.println("Account details\n"+c2);
	 Scanner sc =new Scanner(System.in);
	 System.out.println("Withdraw");
	 System.out.println("Enter the account number from which th emoney i sto be with drawn ");
	 accNo=sc.nextInt();
	 System.out.println("Enter pin number");
	 pinNo=sc.nextInt();
	 System.out.println("Enter the amount of money to be withdrawn ");
	 amount=sc.nextInt();
	 System.out.println(services.withdrawAmount(accNo, amount, pinNo));
	 System.out.println("AccountDetails after withdrawal"+services.getAccountDetails(accNo));
	 System.out.println("Deposit");
	 System.out.println("Enter account number");
	 accNo=sc.nextInt();
	 System.out.println("eNTER AMOUNT TO  BE DEPOSITED");
	 amount=sc.nextInt();
	 System.out.println(services.depositAmount(accNo, amount));
	 System.out.println("Fund Transfer");
	 System.out.println("Enter the account number from which money");
	 accNoFrom=sc.nextInt();
	 System.out.println("Enter the pin number");
	 pinNo=sc.nextInt();
	 System.out.println("enter th eacc to which amount has to be deposited");
	 accNoTo=sc.nextInt();
	 System.out.println("Enter th eamount");
	 float transferAmount=sc.nextInt();
	 boolean b=services.fundTransfer(accNoTo,accNoFrom ,transferAmount, pinNo);
	 if(b) {
		 System.out.println("Account Status of Depositor "+services.getAccountDetails(accNoFrom));
		 System.out.println("Account Status of Receiver\n"+services.getAccountDetails(accNoTo));
	 }
	 
	}
}
