import java.util.HashMap;

import com.cg.banking.beans.Account;

public class BankingDBUtil 
{
  HashMap<Integer, Account> accounts=new HashMap<>();
}
